enum AutoError: Error {
    case error400 // неправильный запрос
    case error404 // не найдено
    case error500 // внутренняя ошибка сервера
    
}

var error400: Bool = true
var error404: Bool = true
var error500: Bool = true

do {
    if error400 {
        throw AutoError.error400 
    }
    
    if error404 {
        throw AutoError.error404
    }
    
    if error500 {
        throw AutoError.error500
    }
} catch AutoError.error400 {
    print("неправильный, некорректный запрос")
} catch AutoError.error404 {
    print("не найдено")
} catch AutoError.error500 {
    print("внутренняя ошибка сервера")
}

func autoDrive() throws {
    if error400 {
        throw AutoError.error400
    }
    
    if error404 {
        throw AutoError.error404
    }
    
    if error500 {
        throw AutoError.error500
    }
}

do {
    try autoDrive()
} catch AutoError.error400 {
    print("неправильный, некорректный запрос")
} catch AutoError.error404 {
    print("не найдено")
}  catch AutoError.error500 {
    print("внутренняя ошибка сервера")
}




func findIndex<Int>(value: [Int], valueToFind: Int) -> Int? {
    if value == valueToFind as! [Int] {
        print("yes")
    }
}
