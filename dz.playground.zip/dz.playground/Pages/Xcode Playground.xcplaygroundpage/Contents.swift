let someTuple = (age: 19, name: "Игорь", surname: "Васельков")
let someTwoTuple = (age: 20, name: "Вася", surname: "Игорьков")
someTuple.0
/// ...
someTwoTuple.age

let days: [String] = ["31 день", "28 дней", "31 день", "30 дней", "31 день", "30 дней", "31 день", "31 день", "30 дней", "31 день", "30 дней", "31 день"]

for index in 0..<days.count {
    print(days[index])
}

let nameMonths: [String] = ["январь", "февраль", "март", "апрель", "май", "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"]

let daysInMonths = days + nameMonths
print(daysInMonths)

let daysInMonths2: [(days: Int, month: String)] = [
(31, "январь"),
(28, "февраль"),
(31, "март"),
(30, "апрель"),
(31, "май"),
(30, "июнь"),
(31, "июль"),
(31, "август"),
(30, "сентябрь"),
(31, "октябрь"),
(30, "ноярь"),
(31, "декабрь")
]
print(daysInMonths2[0...11])

for index in (0 ..< daysInMonths2.count).reversed() {
    print("Day: \(daysInMonths2[index].0) Month: \(daysInMonths2[index].1)")
}



var students: [String: Int] = ["Ivanov": 2, "Vasechkin": 5, "Popov": 3 ]
students["Ivanov"] = 5

let ocenka = Int()

if ocenka >= 3{
    print("good")
   
}
else {
    print("bad")
}

students["rogov"] = 4

students.removeValue(forKey: "Ivanov")

