import Foundation

protocol UserData {
  var userName: String { get }    
  var userCardId: String { get }  
  var userCardPin: Int { get }       
  var userPhone: String { get }      
  var userCash: Float { get set }  
  var userBankDeposit: Float { get set }   
  var userPhoneBalance: Float { get set }    
  var userCardBalance: Float { get set }    
}

enum TextErrors: String {
    case CARD_DETAILS_ENTERED_INCORRECTLY = "Данные карты введены неверно"
    case INVALID_PHONE_NUMBER_ENTERED = "Введен неверный номер телефона"
    case NOT_ENOUGH_CASH = "Недостаточно наличных"
    case NOT_ENOUGH_FUNDS_IN_THE_ACCOUNT = "Недостаточно средств на счете"
}

enum DescriptionTypesAvailableOperations: String {
    case requestBalance = "Запросить баланс"
    case topUpYourPhoneBalance = "Пополнить баланс телефона"
    case withdrawFundsFromAccount = "Снять средства с карты"
    case topUpYourAccount = "Пополнить счет"
}

enum UserActions {
    case userPressedBalanceBtn
    case userPressedTopUpAccount(topUp: Float)
    case userPressedWithdrawCashAccount(withdrawCash: Float)
    case userPressedPayPhone(phone: String)
}

enum PaymentMethod {
    case cash(cash: Float)
    case deposit(deposit: Float)
}

class ATM {
    private let userCardId: String
    private let userCardPin: Int
    private var someBank: BankApi
    private let action: UserActions
    private let paymentMethod: PaymentMethod?
 
    init(userCardId: String, userCardPin: Int, someBank: BankApi, action: UserActions, paymentMethod: PaymentMethod? = nil) {
        
        self.userCardId = userCardId
        self.userCardPin = userCardPin
        self.someBank = someBank
        self.action = action
        self.paymentMethod = paymentMethod
 
    sendUserDataToBank(userCardId: userCardId, userCardPin: userCardPin, actions: action, payment: paymentMethod)
  }
 
 
  public final func sendUserDataToBank(userCardId: String, userCardPin: Int, actions: UserActions, payment: PaymentMethod?) {
    let isUserExist = someBank.checkCurrentUser(userCardId: userCardId, userCardPin: userCardPin)
    if isUserExist {
        switch actions {
        case .userPressedBalanceBtn:
            someBank.showUserBalance()
        case let .userPressedPayPhone(phone):
            if someBank.checkUserPhone(phone: phone) {
                if let payment = payment {
                    switch payment {
                    case let .cash(cash: payment):
                        if someBank.checkMaxUserCash(cash: payment) {
                            someBank.topUpPhoneBalanceCash(pay: payment)
                            someBank.ShowUserToppedUpMobilePhoneCash(cash: payment)
                        } else {
                            someBank.showError(error: .NOT_ENOUGH_CASH)
                        }
                    case let .deposit(deposit: payment):
                        if someBank.checkMaxAccountDeposit(withdraw: payment) {
                            someBank.topUpPhoneBalanceDeposit(pay: payment)
                            someBank.showUserToppedUpMobilePhoneDeposit(deposit: payment)
                        } else {
                            someBank.showError(error: .NOT_ENOUGH_FUNDS_IN_THE_ACCOUNT)
                        }
                    }
                }
            } else {
                someBank.showError(error: .INVALID_PHONE_NUMBER_ENTERED)
            }
        case let .userPressedTopUpAccount(topUp: payment):
            if someBank.checkMaxUserCash(cash: payment) {
                someBank.puyCashDeposit(topUp: payment)
                someBank.showTopUpAccount(cash: payment)
            } else {
                someBank.showError(error: .NOT_ENOUGH_CASH)
            }
        case let .userPressedWithdrawCashAccount(withdrawCash):
            if someBank.checkMaxAccountDeposit(withdraw: withdrawCash) {
                someBank.getCashFromDeposit(cash: withdrawCash)
                someBank.showwithdrawalDeposit(cash: withdrawCash)
            } else {
                someBank.showError(error: .NOT_ENOUGH_FUNDS_IN_THE_ACCOUNT) 
            }
        }
    } else {
        someBank.showError(error: .CARD_DETAILS_ENTERED_INCORRECTLY)
    }
 
  }
}

protocol BankApi {
    func showUserCardBalance()
    func showUserDepositBalance()
    func showUserToppedUpMobilePhoneCash(cash: Float)
    func showUserToppedUpMobilePhoneCard(card: Float)
    func showWithdrawalCard(cash: Float)
    func showWithdrawalDeposit(cash: Float)
    func showTopUpCard(cash: Float)
    func showTopUpDeposit(cash: Float)
    func showError(error: TextErrors)
 
    func checkUserPhone(phone: String) -> Bool
    func checkMaxUserCash(cash: Float) -> Bool
    func checkMaxUserCard(withdraw: Float) -> Bool
    func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool
 
    mutating func topUpPhoneBalanceCash(pay: Float)
    mutating func topUpPhoneBalanceCard(pay: Float)
    mutating func getCashFromDeposit(cash: Float)
    mutating func getCashFromCard(cash: Float)
    mutating func putCashDeposit(topUp: Float)
    mutating func putCashCard(topUp: Float)
}

struct BankServer: BankApi {
    private var user: UserData
    
    init(user: UserData) {
        self.user = user
    }

public func showUserBalance() {
    let report = """
        Здравствуйте, \(user.userName)
        \(DescriptionTypesAvailableOperations.balance.rawValue)
        Ваш баланс депозита составляет: \(user.userBankDeposit) рублей
        Хорошего дня!
        """
    print(report)
}
    
public func showUserToppedUpMobilePhoneCash(cash: Float){
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.phone.rawValue)
            Вы пополили баланс наличными на сумму: \(cash)
            У вас осталось \(user.userCash) рублей наличными
            Баланс вашего телефона составляет: \(user.userPhoneBalance) рублей
            Хорошего дня!
            """
        print(report)
    }
    
    public func showUserToppedUpMobilePhoneDeposit(deposit: Float){
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.phone.rawValue)
            Вы пополнили баланс с депозитных средств на сумму: \(deposit)
            У вас осталось на депозите: \(user.userBankDeposit)
            Баланс вашего телефона составляет: \(user.userPhoneBalance) рублей
            Хорошего дня!
            """
        print(report)
    }
    
    func showWithdrawalDeposit(cash: Float) {
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.withdrawal.rawValue)
            Вы сняли с депозита средства на сумму: \(cash)
            У вас осталось на депозите: \(user.userBankDeposit) рублей
            У вас осталось наличных: \(user.userCash) рублей
            Хорошего дня!
            """
        print(report)
    }
    
    func showTopUpAccount(cash: Float) {
        let report = """
            Здравствуйте, \(user.userName)
            \(DescriptionTypesAvailableOperations.topUp.rawValue)
            Вы пополнили депозит на сумму: \(cash)
            Сумма депозита составляет: \(user.userBankDeposit) рублей
            У вас осталось наличных: \(user.userCash) рублей
            Хорошего дня!
            """
        print(report)
    }
    
    func showError(error: TextErrors) {
        let error = """
            Здравствуйте, \(user.userName)
            Ошибка: \(error.rawValue)
            Хорошего дня!
            """
        print(error)
    }
    
    public mutating func putCashDeposit(topUp: Float) {
        user.userBankDeposit += topUp
        user.userCash += topUp
     } 
    
public mutating func getCashFromDeposit(cash: Float) {
    user.userBankDeposit -= cash
    user.userCash += cash
}
    
public mutating func topUpPhoneBalanceCash(pay: Float) {
    user.userPhoneBalance += pay
    user.userCash -= pay
}
    
    public mutating func topUpPhoneBalanceDeposit(pay: Float) {
        user.userPhoneBalance += pay
        user.userCash -= pay
    }
    
    public func checkMaxAccountDeposit(withdraw: Float) -> Bool {
        if withdraw <= user.userBankDeposit {
            return true
        }
        return false
    }
    
    public func checkUserPhone(phone: String) -> Bool {
       if phone == user.userPhone {
       return true
       }
       return false
    }
    
   public func checkCurrentUser(userCardId: String, userCardPin: Int) -> Bool {
       let isCorrectId = checkId(id: userCardId, user: user)
       let isCorrectPin = checkPin(pin: userCardPin, user: user)
    
       if isCorrectId && isCorrectPin {
       return true
       }
       return false
   }
    
   private func checkPin(pin: Int, user: UserData) -> Bool {
       if pin == user.userCardPin {
         return true
       }
       return false
   }
      
    private func checkId(id: String, user: UserData) -> Bool {
       if id == user.userCardId {
       return true
       }
       return false
   }
}

struct User: UserData {
    var userName: String     
     var userCardId: String 
     var userCardPin: Int     
     var userPhone: String      
     var userCash: Float 
     var userBankDeposit: Float  
     var userPhoneBalance: Float    
     var userCardBalance: Float 
}

let ivan_davankov: UserData = User(
    userName: "Ivan Davankov",
    userCardId: "2838 7302 2434 5001",
    userCardPin: 5790,
    userPhone: "+7(987)-228-88-14", userCash: 3500.56,
    userBankDeposit: 7800,
    userPhoneBalance: 3, userCardBalance: <#Float#>
)

let bankClient = BankServer(user: ivan_davankov)

let atmKKB = ATM(
    userCardId: "2838 7302 2434 5001",
    userCardPin: 5790,
    someBank: bankClient,
    action: .userPressedPayPhone(phone: "+7(987)-228-88-14"),
    paymentMethod: .cash(cash: 500)
)


